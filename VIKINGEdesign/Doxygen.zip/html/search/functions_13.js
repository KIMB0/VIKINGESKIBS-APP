var searchData=
[
  ['savebilleterasjsonasync',['SaveBilleterAsJsonAsync',['../class_v_i_k_i_n_g_edesign_1_1_persistency_1_1_persistency_service.html#af67e2a2bd42d642dcf8daa653b7a0e9b',1,'VIKINGEdesign::Persistency::PersistencyService']]],
  ['savekunderasjsonasync',['SaveKunderAsJsonAsync',['../class_v_i_k_i_n_g_edesign_1_1_persistency_1_1_persistency_service.html#a806161f90754029d2ed27b6f911e8837',1,'VIKINGEdesign::Persistency::PersistencyService']]],
  ['savestateeventargs',['SaveStateEventArgs',['../class_v_i_k_i_n_g_edesign_1_1_common_1_1_save_state_event_args.html#aa4e2bde9b9ce8fc0d10476159cd89e85',1,'VIKINGEdesign::Common::SaveStateEventArgs']]],
  ['savestateeventhandler',['SaveStateEventHandler',['../namespace_v_i_k_i_n_g_edesign_1_1_common.html#a5d41fd2e369f34021007c08f9eb6aa55',1,'VIKINGEdesign::Common']]],
  ['setpositivenumber',['setPositiveNumber',['../bin_2_debug_2_app_x_2_scripts_2jquery-1_89_81_8js.html#a049182834e8b4b2d7485cd919ed272d7',1,'setPositiveNumber(elem, value, subtract):&#160;jquery-1.9.1.js'],['../_scripts_2jquery-1_89_81_8js.html#a049182834e8b4b2d7485cd919ed272d7',1,'setPositiveNumber(elem, value, subtract):&#160;jquery-1.9.1.js']]],
  ['setselectedskibe',['SetSelectedSkibe',['../class_v_i_k_i_n_g_edesign_1_1_handler_1_1_skibe_handler.html#a2a5af22695d9778b2ff2f760f117dfb9',1,'VIKINGEdesign::Handler::SkibeHandler']]],
  ['showhide',['showHide',['../bin_2_debug_2_app_x_2_scripts_2jquery-1_89_81_8js.html#a002b8e481f3ab2a83194366aceb7a706',1,'showHide(elements, show):&#160;jquery-1.9.1.js'],['../_scripts_2jquery-1_89_81_8js.html#a002b8e481f3ab2a83194366aceb7a706',1,'showHide(elements, show):&#160;jquery-1.9.1.js']]],
  ['skibehandler',['SkibeHandler',['../class_v_i_k_i_n_g_edesign_1_1_handler_1_1_skibe_handler.html#a137be6267a46a2b6cdce4dc0b5004efa',1,'VIKINGEdesign::Handler::SkibeHandler']]],
  ['sn',['sn',['../bin_2_debug_2_app_x_2_scripts_2jquery-1_89_81_8min_8js.html#abccbe99209ac0b8dff41f1baddfc4d70',1,'sn(e, t, n):&#160;jquery-1.9.1.min.js'],['../_scripts_2jquery-1_89_81_8min_8js.html#abccbe99209ac0b8dff41f1baddfc4d70',1,'sn(e, t, n):&#160;jquery-1.9.1.min.js']]],
  ['stringformatmethodattribute',['StringFormatMethodAttribute',['../class_string_format_method_attribute.html#a39256792ebf736db384513a1e9d88240',1,'StringFormatMethodAttribute']]],
  ['suspensionmanagerexception',['SuspensionManagerException',['../class_v_i_k_i_n_g_edesign_1_1_common_1_1_suspension_manager_exception.html#a045b0391ce243f3c2ad37e03067f90d5',1,'VIKINGEdesign.Common.SuspensionManagerException.SuspensionManagerException()'],['../class_v_i_k_i_n_g_edesign_1_1_common_1_1_suspension_manager_exception.html#a84ab8bbc4bf7cad5afebd97f9417c00c',1,'VIKINGEdesign.Common.SuspensionManagerException.SuspensionManagerException(Exception e)']]]
];
