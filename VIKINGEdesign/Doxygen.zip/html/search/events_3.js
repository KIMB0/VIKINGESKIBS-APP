var searchData=
[
  ['propertychanged',['PropertyChanged',['../class_v_i_k_i_n_g_edesign_1_1_model_1_1_billet.html#a540836cd7b0ba2c7c4a73fbd7bcd6a66',1,'VIKINGEdesign.Model.Billet.PropertyChanged()'],['../class_v_i_k_i_n_g_edesign_1_1_model_1_1_vikingeskibe.html#a488be409970c589bef4973f6e280ddde',1,'VIKINGEdesign.Model.Vikingeskibe.PropertyChanged()'],['../class_v_i_k_i_n_g_edesign_1_1_view_model_1_1_main_view_model.html#a723abec6ad7f77b7992f99406d18cbbd',1,'VIKINGEdesign.ViewModel.MainViewModel.PropertyChanged()']]]
];
