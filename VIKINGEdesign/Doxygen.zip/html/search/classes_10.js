var searchData=
[
  ['vikingecatalogsingleton',['VikingeCatalogSingleton',['../class_v_i_k_i_n_g_edesign_1_1_model_1_1_vikinge_catalog_singleton.html',1,'VIKINGEdesign::Model']]],
  ['vikingeskibe',['Vikingeskibe',['../class_v_i_k_i_n_g_edesign_1_1_model_1_1_vikingeskibe.html',1,'VIKINGEdesign::Model']]]
];
