var searchData=
[
  ['savestate',['SaveState',['../class_v_i_k_i_n_g_edesign_1_1_common_1_1_navigation_helper.html#a17362aea6145ab1f1852d72229e953f7',1,'VIKINGEdesign::Common::NavigationHelper']]]
];
