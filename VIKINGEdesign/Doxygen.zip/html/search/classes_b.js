var searchData=
[
  ['observabledictionary',['ObservableDictionary',['../class_v_i_k_i_n_g_edesign_1_1_common_1_1_observable_dictionary.html',1,'VIKINGEdesign::Common']]]
];
