var searchData=
[
  ['observabledictionary_2ecs',['ObservableDictionary.cs',['../_observable_dictionary_8cs.html',1,'']]]
];
